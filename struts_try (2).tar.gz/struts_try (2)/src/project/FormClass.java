package project;

import org.apache.struts.action.ActionForm;

public class FormClass extends ActionForm{
	
	private String toAccount=null,fromAccount=null,amount=null;
	
	public void setToAccount(String toAcc) {
		toAccount = toAcc;
	}
	
	public String getToAccount() {
		return toAccount;
	}
	
	public void setFromAccount(String fromAcc) {
		fromAccount = fromAcc;
	}
	
	public String getFromAccount() {
		return fromAccount;
	}
	public void setAmount(String amt) {
		amount = amt;
	}
	
	public String getAmount() {
		return amount;
	}

}
