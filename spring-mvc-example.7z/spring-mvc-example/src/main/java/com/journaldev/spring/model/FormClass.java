package com.journaldev.spring.model;


public class FormClass extends ActionForm{
	
	private String toAccount=null,fromAccount=null,amount=null;
	
	public void setToAccount(String toAcc) {
		this.toAccount = toAcc;
	}
	
	public String getToAccount() {
		return toAccount;
	}
	
	public void setFromAccount(String fromAcc) {
		this.fromAccount = fromAcc;
	}
	
	public String getFromAccount() {
		return fromAccount;
	}
	public void setAmount(String amt) {
		this.amount = amt;
	}
	
	public String getAmount() {
		return amount;
	}

}

