package com.journaldev.spring.model;

public class ActionForm {

}
