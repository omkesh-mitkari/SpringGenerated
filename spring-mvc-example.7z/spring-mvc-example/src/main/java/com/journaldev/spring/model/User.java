
package com.journaldev.spring.model;

public class User {
	private String userName;
	private int amount;
	public String getUserName() {
		return userName;
	}
	public int getamount()
	{
		return amount;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setamount(int amount) {
		this.amount = amount;
	}
}
