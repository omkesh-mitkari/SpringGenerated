package com.journaldev.spring.controller;


import com.journaldev.spring.model.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class ActionClass {
	
	public static String execute( ActionForm form, HttpServletRequest req,HttpServletResponse res) {
		
		String toAccount=null,fromAccount=null,amount=null;
		
		FormClass fc = (FormClass)form;
		toAccount = fc.getToAccount();
		fromAccount = fc.getFromAccount();
		amount = fc.getAmount();
		
		//System.out.println("username:"+username+" passwd:"+passwd);
		
		/*username = req.getParameter("username");
		passwd = req.getParameter("pass");
		fc.setUserName(username);
		fc.setPassword(passwd);
		System.out.println("username:"+username+" passwd:"+passwd);
		*/
		
		HttpSession session = req.getSession();
		session.setAttribute("FormClass",	fc);
		
		if((toAccount != null)&&(fromAccount!=null)) {
			
			return "user";
		}
		else {
			return "user";
		}
		
	}

}

