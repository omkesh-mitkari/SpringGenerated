package project;

import project.ConvertActionForm;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import project.FormClass;

public class ActionClass extends Action{
	
	public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req,HttpServletResponse res) throws IllegalArgumentException, IllegalAccessException, ClassNotFoundException, InstantiationException {
		String className = "project.FormClass";
		
		//FormClass fc1 = new FormClass();
		Object c2 =  Class.forName(className).newInstance();
		Object fc1 = c2;
		
		ConvertActionForm aform = new ConvertActionForm();
		aform.putFormClassName(fc1);
		fc1 = aform.formBean(req);
		
		Class<? extends Object> c1 = fc1.getClass();
		try {
			Method m = c1.getDeclaredMethod("getAmount");
			System.out.println("invoke amount:"+m.invoke(fc1));
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}

/*		System.out.println("amt:"+fc1.getAmount());
		System.out.println("fromAccount:"+fc1.getFromAccount());
		System.out.println("toAccount:"+fc1.getToAccount());
		*/
		String toAccount=null,fromAccount=null,amount=null;
		
		FormClass fc = (FormClass)form;
		toAccount = fc.getToAccount();
		fromAccount = fc.getFromAccount();
		amount =  fc.getAmount();
		
		if(fc1.equals(fc)) {
			System.out.println("Objects are equal");
		}	
		
		//System.out.println("username:"+username+" passwd:"+passwd);
		
	/*	username = req.getParameter("username");
		passwd = req.getParameter("pass");
		fc.setUserName(username);
		fc.setPassword(passwd);
		System.out.println("username:"+username+" passwd:"+passwd);
		*/
		
		HttpSession session = req.getSession();
		session.setAttribute("FormClass",fc1);	
		
		if((toAccount != null)&&(fromAccount!=null)) {		
			return map.findForward("success");
		}
		else {
			return map.findForward("failure");
		}
		
	}

}
