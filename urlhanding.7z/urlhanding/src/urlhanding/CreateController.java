package urlhanding;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.io.FileReader;
import java.nio.file.*;
public class CreateController {
	public static Hashtable<String,String> h = new Hashtable<String,String>();
	public static Hashtable<String,String> h1 = new Hashtable<String,String>();
	public static Hashtable<String,String> h2 = new Hashtable<String,String>();
	
	public static void addheader(FileWriter fstream1,BufferedWriter out1) throws IOException {
 
		File fin = new File("headerfiles.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
 
 
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			//Process each line and add output to Dest.txt file
			out1.write(aLine);
			out1.newLine();
		}
		in.close();
	}
	
	public static String searchInTable(Hashtable<String,String> h1,String searchKey)
	{
		Set<String> keys = h1.keySet();
        Iterator<String> iterator = keys.iterator();
        
        while(iterator.hasNext())
        {
        	String key= iterator.next();
        	if(key.equals(searchKey))
        		return h1.get(key);
        }
        return "NULL";
	}
	
	public static void addControllerMethod(FileWriter fstream1,BufferedWriter out1,String oldString, String newString,String oldString1, String newString1,Hashtable<String,String> h1,Hashtable<String,String> h2) throws IOException {
		 
		File fin1 = new File("controllerMethodTemplate.txt");
		FileInputStream fis1 = new FileInputStream(fin1);
		BufferedReader in1 = new BufferedReader(new InputStreamReader(fis1));
		
		String formName;
		String className;
		xmlparser xmlparse = new xmlparser();
		
		formName = searchInTable(h2,newString1);
		
		
		className =searchInTable(h1,formName);
		System.out.println("//////////////////////////  ");
		System.out.println(className+"  "+formName);
		
 
		String aLine = null;
		while ((aLine = in1.readLine()) != null) {
			//Process each line and add output to Dest.txt file
			aLine = aLine.replaceAll(oldString, newString);
			aLine = aLine.replaceAll(oldString1, newString1);
			aLine = aLine.replaceAll("classNameString",className);
			out1.write(aLine);
			out1.newLine();
		}
 
		// do not forget to close the buffer reader
		in1.close();
	}
	
	
	public static void modifyFile(String filePath, String oldString, String newString)
    {
		try{
		    FileReader fr = new FileReader(filePath);
		    String s,s1;
		    String totalStr = "";
		    try (BufferedReader br = new BufferedReader(fr)) {
		    	FileWriter fw = new FileWriter("modifiedcontroller.java");
		        while ((s = br.readLine()) != null) {
		            //totalStr += s
		        	s1 = s;
		        System.out.println("old s:"+s);   	    	
		        	s = s.replaceAll(oldString, newString);
		        	
			     System.out.println("new s:"+s);   	
			        	fw.write(s);
			        	fw.write("\n");
			        	if(!s1.equals(s))
			        		break;
		        	
		        }
		       // totalStr = totalStr.replaceAll(oldString, newString);
		    fw.close();
		    }
		}catch(Exception e){
		    e.printStackTrace();
		}
    }
	public static void addDispatcherServelet(FileWriter fstream1,BufferedWriter out1) throws IOException {
		 
		File fin = new File("dispatcherTemplate.txt");
		FileInputStream fis = new FileInputStream(fin);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis));
 
 
		String aLine = null;
		while ((aLine = in.readLine()) != null) {
			//Process each line and add output to Dest.txt file
			out1.write(aLine);
			out1.newLine();
		}
		in.close();
	}
	
	public static void main(String args[]) throws Exception
	{
		
		FileStructure fileStructure = new FileStructure();
		fileStructure.createDirectoryStructure();
		
		System.out.println("Directory Structure created successfully....\n");
		
		AddLibrary addLibrary = new AddLibrary();
		addLibrary.addJars("C:\\Users\\Admin\\Desktop\\Project Phase1\\SpringJars", "C:\\Users\\Admin\\Desktop\\Project\\Struts\\WebContent\\WEB-INF\\lib");
		
		System.out.println("Jars Added to lib folder successfully....\n");
		
		WebXMLParser webXMLParser = new WebXMLParser();
		webXMLParser.convertWebXML();
		
		
		
		ConvertClass convertClass = new ConvertClass();
		convertClass.preprocessActionClass();
		
		//FormClassConversion formClassConversion = new FormClassConversion();
		//formClassConversion.convertFormBean();
		
		
		FileWriter fstream12 = new FileWriter("C:\\Users\\Admin\\Desktop\\Project\\Struts\\WebContent\\WEB-INF/project-sevelet.xml", true);
		BufferedWriter out12 = new BufferedWriter(fstream12);
		
		addDispatcherServelet(fstream12,out12);
		out12.close();
		
		FileWriter fstream1 = new FileWriter("C:\\Users\\Admin\\Desktop\\Project\\Struts\\src/controller.java", true);
		BufferedWriter out1 = new BufferedWriter(fstream1);
		addheader(fstream1,out1);
		//addControllerMethod();
		int i=0;
		xmlparser xmlparse = new xmlparser();
		
		/* Hashtable to create the action class and url mappinfg
		 * 
		 */
		h = xmlparse.getMappings();
		h2=xmlparse.getFormHelpMappings();
		h1=xmlparse.getFormMappings();
		Set<String> keys = h.keySet();
        Iterator<String> iterator = keys.iterator();
        
        while(iterator.hasNext())
        {
        	String key= iterator.next();
        	addControllerMethod(fstream1,out1,"ClassName",h.get(key),"/dummy",key,h1,h2);
        }
        
		out1.newLine();
		out1.write("}");
		out1.close();
		
		Files.move(Paths.get("C:\\Users\\Admin\\Desktop\\STS\\urlhanding\\src\\urlhanding/ConvertActionForm.java"),Paths.get("C:\\Users\\Admin\\Desktop\\Project\\Struts\\src/ConvertActionForm.java") );
		Files.move(Paths.get("C:\\Users\\Admin\\Desktop\\STS\\urlhanding\\src\\urlhanding/formHelper.java"),Paths.get("C:\\Users\\Admin\\Desktop\\Project\\Struts\\src/formHelper.java") );
	}
}
