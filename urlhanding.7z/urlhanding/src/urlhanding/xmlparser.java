package urlhanding;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class xmlparser {
		
		public static Hashtable<String,String> h = new Hashtable<String,String>();
		public static Hashtable<String,String> h1 = new Hashtable<String,String>();
		public static Hashtable<String,String> h2 = new Hashtable<String,String>();
		
		public static Hashtable<String,String> getMappings() {
	      try {
	         
	    	 File inputFile = new File("C:\\Users\\Admin\\Desktop\\struts_try\\WebContent\\WEB-INF/struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("path"));
	               System.out.println(eElement.getAttribute("type"));
	               h.put(eElement.getAttribute("path"),eElement.getAttribute("type"));
	            }
	         }
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
		  return h;
	   }
		
		
		
		public static Hashtable<String,String> getFormMappings()
		{
			 try
			 {
			 File inputFile = new File("C:\\Users\\Admin\\Desktop\\struts_try\\WebContent\\WEB-INF/struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("form-bean");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("name"));
	               System.out.println(eElement.getAttribute("type"));
	               h1.put(eElement.getAttribute("name"),eElement.getAttribute("type"));
	            }
	         }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			 return h1;
		}
		public static Hashtable<String,String> getFormHelpMappings()
		{
			 try
			 {
			 File inputFile = new File("C:\\Users\\Admin\\Desktop\\struts_try\\WebContent\\WEB-INF/struts-config.xml");
	         DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         
	         Document doc = dBuilder.parse(inputFile);
	         
	         doc.getDocumentElement().normalize();
	         
	         //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("action");
	         
	         System.out.println("----------------------------");
	         
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            System.out.println("\nCurrent Element :" + nNode.getNodeName());
	            
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println(eElement.getAttribute("name"));
	               System.out.println(eElement.getAttribute("path"));
	               h2.put(eElement.getAttribute("path"),eElement.getAttribute("name"));
	            }
	            
	         }
			 }
			 catch (Exception e) {
		         e.printStackTrace();
		      }
			 return h2;
		}
}
