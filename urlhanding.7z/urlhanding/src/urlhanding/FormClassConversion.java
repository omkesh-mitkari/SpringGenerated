package urlhanding;

import java.io.*;

public class FormClassConversion {
	public static void convertFormBean() throws IOException {
		String buffer = "";
		int i;
		char ch;
		byte b[];
		
		FileInputStream fin = new FileInputStream("C:\\Users\\Admin\\Desktop\\struts_try\\src\\project/FormClass.java");
		FileOutputStream fout = new FileOutputStream("C:\\Users\\Admin\\Desktop\\Project\\Struts\\src/FormClass.java");
		
		//fin.read() returns ascii value of read char
		while((i = fin.read()) != -1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n')) {
				if(buffer.equals("extends")) {
					handleActionForm(fin,fout);
					buffer = "";
				}
				else if((ch == ' ')||(ch == '\n')) {
					buffer += ch;
					System.out.print(buffer);
					b = buffer.getBytes();
					fout.write(b);
					buffer = "";					
				}
			}
			else {
				buffer += ch;
			}
		}
		
		fin.close();
		fout.close();
		
		File oldfile = new File("FormClass.java");
		File newfile = new File("TemporaryFormClass.java");
		
		if(oldfile.delete()) {
			boolean success = newfile.renameTo(oldfile);
			if(!success) {
				System.out.println("File couldnt be renamed");
			}
		}
		else {
			System.out.println("Files could not be deleted ");
		}
	}
	
	static void handleActionForm(FileInputStream fin,FileOutputStream fout) throws IOException {
		ignoreUntil(fin,fout,"ActionForm");		//ignores till the word 'ActionForm'
	}
	
	static void ignoreUntil(FileInputStream fin,FileOutputStream fout,String str) throws IOException {		//ignores everything till String 'str'
		String buffer = "";
		char ch = ' ';
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == '.')) {
				if(buffer.equals(str)) {
					break;
				}
				else{
					buffer = "";
				}
			}
			else if(ch == '\t'){
				//ignore
			}
			else {		
				buffer += ch;
			}
		}
		System.out.print(ch);
		buffer = "";
		buffer += ch;
		b = buffer.getBytes();
		fout.write(b);
	}

}


